# Device Tree for Xiaomi SDM439 Devices (Mi439)
